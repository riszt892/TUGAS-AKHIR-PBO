--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.3
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cigar_in;
--
-- Name: cigar_in; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE cigar_in WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE cigar_in OWNER TO postgres;

\connect cigar_in

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: counter_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.counter_record (
    id_record integer NOT NULL,
    record_transaksi integer NOT NULL
);


ALTER TABLE public.counter_record OWNER TO postgres;

--
-- Name: counter_record_id_record_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.counter_record_id_record_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.counter_record_id_record_seq OWNER TO postgres;

--
-- Name: counter_record_id_record_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.counter_record_id_record_seq OWNED BY public.counter_record.id_record;


--
-- Name: kemasan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kemasan (
    id_kemasan integer NOT NULL,
    ukuran character varying(15) NOT NULL,
    jumlah_cigar integer
);


ALTER TABLE public.kemasan OWNER TO postgres;

--
-- Name: kemasan_id_kemasan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kemasan_id_kemasan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kemasan_id_kemasan_seq OWNER TO postgres;

--
-- Name: kemasan_id_kemasan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kemasan_id_kemasan_seq OWNED BY public.kemasan.id_kemasan;


--
-- Name: produk; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produk (
    id_produk integer NOT NULL,
    nama character varying(30) NOT NULL,
    id_kemasan integer NOT NULL,
    harga integer NOT NULL,
    stok integer NOT NULL,
    status character varying(15)
);


ALTER TABLE public.produk OWNER TO postgres;

--
-- Name: produk_id_produk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produk_id_produk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produk_id_produk_seq OWNER TO postgres;

--
-- Name: produk_id_produk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produk_id_produk_seq OWNED BY public.produk.id_produk;


--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaksi (
    id_transaksi integer NOT NULL,
    id_produk integer NOT NULL,
    jumlah integer NOT NULL,
    record_transaksi integer
);


ALTER TABLE public.transaksi OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transaksi_id_transaksi_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaksi_id_transaksi_seq OWNER TO postgres;

--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transaksi_id_transaksi_seq OWNED BY public.transaksi.id_transaksi;


--
-- Name: counter_record id_record; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.counter_record ALTER COLUMN id_record SET DEFAULT nextval('public.counter_record_id_record_seq'::regclass);


--
-- Name: kemasan id_kemasan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kemasan ALTER COLUMN id_kemasan SET DEFAULT nextval('public.kemasan_id_kemasan_seq'::regclass);


--
-- Name: produk id_produk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produk ALTER COLUMN id_produk SET DEFAULT nextval('public.produk_id_produk_seq'::regclass);


--
-- Name: transaksi id_transaksi; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi ALTER COLUMN id_transaksi SET DEFAULT nextval('public.transaksi_id_transaksi_seq'::regclass);


--
-- Data for Name: counter_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.counter_record (id_record, record_transaksi) FROM stdin;
\.
COPY public.counter_record (id_record, record_transaksi) FROM '$$PATH$$/3013.dat';

--
-- Data for Name: kemasan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kemasan (id_kemasan, ukuran, jumlah_cigar) FROM stdin;
\.
COPY public.kemasan (id_kemasan, ukuran, jumlah_cigar) FROM '$$PATH$$/3015.dat';

--
-- Data for Name: produk; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produk (id_produk, nama, id_kemasan, harga, stok, status) FROM stdin;
\.
COPY public.produk (id_produk, nama, id_kemasan, harga, stok, status) FROM '$$PATH$$/3017.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transaksi (id_transaksi, id_produk, jumlah, record_transaksi) FROM stdin;
\.
COPY public.transaksi (id_transaksi, id_produk, jumlah, record_transaksi) FROM '$$PATH$$/3019.dat';

--
-- Name: counter_record_id_record_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.counter_record_id_record_seq', 1, true);


--
-- Name: kemasan_id_kemasan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kemasan_id_kemasan_seq', 3, true);


--
-- Name: produk_id_produk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produk_id_produk_seq', 4, true);


--
-- Name: transaksi_id_transaksi_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transaksi_id_transaksi_seq', 10, true);


--
-- Name: counter_record counter_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.counter_record
    ADD CONSTRAINT counter_record_pkey PRIMARY KEY (id_record);


--
-- Name: kemasan kemasan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kemasan
    ADD CONSTRAINT kemasan_pkey PRIMARY KEY (id_kemasan);


--
-- Name: produk produk_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produk
    ADD CONSTRAINT produk_pkey PRIMARY KEY (id_produk);


--
-- Name: transaksi transaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi
    ADD CONSTRAINT transaksi_pkey PRIMARY KEY (id_transaksi);


--
-- Name: produk id_kemasan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produk
    ADD CONSTRAINT id_kemasan FOREIGN KEY (id_kemasan) REFERENCES public.kemasan(id_kemasan);


--
-- Name: transaksi id_produk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaksi
    ADD CONSTRAINT id_produk FOREIGN KEY (id_produk) REFERENCES public.produk(id_produk);


--
-- PostgreSQL database dump complete
--

